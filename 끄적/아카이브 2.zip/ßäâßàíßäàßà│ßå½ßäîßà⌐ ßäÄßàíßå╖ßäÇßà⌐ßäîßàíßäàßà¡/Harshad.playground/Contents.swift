func number(_ N: Int) {
        let add: Int = 10
        for num in N {
            add % num
        if num == 0 {
            print("Harshad")
            
            }
            return number(N.count)
        }
        
    }
number(365)
