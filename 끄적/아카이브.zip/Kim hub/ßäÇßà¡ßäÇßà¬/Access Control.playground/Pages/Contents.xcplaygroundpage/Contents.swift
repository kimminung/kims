/*:
 # Access Control
 
 1. **Access Control**
 2. **Basic Example**
 3. **Getters and Setters**
 4. **Types**
 
 by Giftbot
*/
//: [Next](@next)
