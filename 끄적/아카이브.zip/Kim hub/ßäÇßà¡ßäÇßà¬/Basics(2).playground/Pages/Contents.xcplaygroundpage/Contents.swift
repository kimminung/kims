/*:

 # The Basics
 [The Swift Programming Language](https://developer.apple.com/library/content/documentation/Swift/Conceptual/Swift_Programming_Language/StringsAndCharacters.html#)
 
 * Conditional Statements
 * Loops
 * Tuples
 * Control Transfer
 * Enumerations
 */

//: [Next](@next)
