//
//  AppDelegate.swift
//  Calculator-Example
//
//  Created by giftbot on 2018. 6. 3..
//  Copyright © 2018년 giftbot. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

  var window: UIWindow?
}
