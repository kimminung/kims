/*:
 # OOP : Object-Oriented Programming
 
 1. **Basic Example**
 2. **Initialize**
 3. **Property**
 4. **Practice**
 5. **Abstraction**
 6. **Encapsulation**
 7. **Inheritance**
 8. **Polymorphism**
 
 by Giftbot
*/
//: [Next](@next)
