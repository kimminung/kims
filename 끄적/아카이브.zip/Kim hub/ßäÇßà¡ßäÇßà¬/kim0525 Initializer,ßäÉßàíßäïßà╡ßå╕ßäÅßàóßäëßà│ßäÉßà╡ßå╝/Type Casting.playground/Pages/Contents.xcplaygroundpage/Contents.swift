/*:
 # Type Casting
 
 1. **Any, AnyObject**
 2. **Type Check**
 3. **Type Casting**
 
 by Giftbot
*/
//: [Next](@next)
