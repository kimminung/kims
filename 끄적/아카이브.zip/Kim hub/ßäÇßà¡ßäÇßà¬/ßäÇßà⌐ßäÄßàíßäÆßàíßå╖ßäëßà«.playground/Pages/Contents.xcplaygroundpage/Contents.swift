/*:
 # High Order Functions
 
 1. **Closure**
 2. **High-Order Functions**
    - **forEach**
    - **map**
    - **filter**
    - **reduce**
    - **flatMap (+ compactMap)**
 
 by Giftbot
 */

//: [Next](@next)
