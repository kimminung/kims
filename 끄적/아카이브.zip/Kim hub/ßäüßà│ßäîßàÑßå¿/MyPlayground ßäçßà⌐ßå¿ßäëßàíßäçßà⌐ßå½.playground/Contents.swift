//: Playground - noun: a place where people can play

import Foundation

print(3.14)

var num = 1
print(num)

print ("숫자", num)
// 주석
// 특정부분 비활성화
// 협업 또는 인계 시 이해를 돕기 위해
// 자신을 위해
// 문서화
print("숫자\(num)")

print("숫자"+String(num))

var numStr = "!"

print("숫자"+numStr)
