/*
Question

친구 목록을 출력하는 내용을 구현
friendList(배열) 옵셔널 변수 만들기
func addFriend(name: String) 만들기
printFriendList() 함수 만들기

지금까지 구현해봤던 함수나 클래스 속성을 옵셔널을 이용해 적용할 수 있었는지 확인해보고 수정해보기
*/
class friend {
    
    let name: Array<String> = ["김땡땡", "땡민땡", "땡땡웅"]
    
    func addFriend(name: Array<String>?) {
        
    }
}
