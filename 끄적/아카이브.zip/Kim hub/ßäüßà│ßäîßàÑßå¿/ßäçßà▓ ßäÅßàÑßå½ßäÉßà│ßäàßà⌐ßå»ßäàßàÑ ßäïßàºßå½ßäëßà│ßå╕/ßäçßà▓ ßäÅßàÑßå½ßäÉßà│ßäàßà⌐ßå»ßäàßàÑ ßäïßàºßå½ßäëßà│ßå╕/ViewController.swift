//
//  ViewController.swift
//  뷰 컨트롤러 연습
//
//  Created by 김민웅 on 2018. 6. 1..
//  Copyright © 2018년 김민웅. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }



}

