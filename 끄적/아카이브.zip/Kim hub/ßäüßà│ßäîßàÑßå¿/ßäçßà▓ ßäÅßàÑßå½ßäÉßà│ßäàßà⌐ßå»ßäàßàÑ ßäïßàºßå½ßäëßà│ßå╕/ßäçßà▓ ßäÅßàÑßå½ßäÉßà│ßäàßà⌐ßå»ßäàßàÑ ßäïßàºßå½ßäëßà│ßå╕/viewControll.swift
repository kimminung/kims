//
//  viewControll.swift
//  뷰 컨트롤러 연습
//
//  Created by 김민웅 on 2018. 6. 1..
//  Copyright © 2018년 김민웅. All rights reserved.
//

import UIKit

class viewControll: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
