//
//  AppDelegate.swift
//  LoginPage0620
//
//  Created by Jo JANGHUI on 2018. 6. 20..
//  Copyright © 2018년 JhDAT. All rights reserved.
//

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        return true
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        print("1. applicationDidBecomeActive / Active로 전환된 직후")
    }
    
    func applicationWillResignActive(_ application: UIApplication) {
       print("2. applicationWillResignActive / InActive(비할성) 상태로 전환 되기 직전")
}

    func applicationDidEnterBackground(_ application: UIApplication) {
        print("3. applicationDidEnterBackground / Background로 전환된 직후")
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        print("4. applicationWillEnterForeground / Active 상태가 되기 직전에, 화면에 보여지기 직전의 시점에 호출")
    }
    
    func applicationWillTerminate(_ application: UIApplication) {
        print("5. applicationWillTerminate / App이 종료되기 직전에 호출")
    }
    

}

