//
//  autolayout.swift
//  LoginPage0620
//
//  Created by Jo JANGHUI on 2018. 6. 21..
//  Copyright © 2018년 JhDAT. All rights reserved.
//

import UIKit

protocol AutoLayoutDelegate: class {
    func imageAutoLayout (imageidx imageName: String, equalTo: UIView, top: CGFloat, lead: CGFloat)
}

class AutoLayout {
    weak var delegate: AutoLayoutDelegate?

    func imageAutoLayout (imageidx imageName: String, equalTo: UIView, top: CGFloat, lead: CGFloat) {
        delegate?.imageAutoLayout(imageidx: imageName, equalTo: equalTo, top: top, lead: lead)
        let image = UIImageView(image: UIImage(named: imageName))
        equalTo.addSubview(image)
        equalTo.translatesAutoresizingMaskIntoConstraints = false
        equalTo.topAnchor.constraint(equalTo: equalTo.topAnchor, constant: top).isActive = true
        equalTo.leadingAnchor.constraint(equalTo: equalTo.leadingAnchor, constant: lead).isActive = true
    }
}

