//
//  KeyboardViewController.swift
//  LoginProject
//
//  Created by seob on 2018. 7. 6..
//  Copyright © 2018년 seob. All rights reserved.
//

import UIKit

class KeyboardViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
  

//    guard let info = sender.userInfo ,
//    let keyboardFrame = info[UIKeyboardFrameEndUserInfoKey] as? CGRect
//    else { return }
//    print(keyboardFrame.height)
    
}
