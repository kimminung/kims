//
//  User.swift
//  LoginProject
//
//  Created by seob on 2018. 7. 3..
//  Copyright © 2018년 seob. All rights reserved.
//

import UIKit

class User: NSObject {
    var name: String?
    var email: String?
    var profile: NSURL?
}
