//
//  DisplayController.swift
//  Test1
//
//  Created by seob on 2018. 6. 9..
//  Copyright © 2018년 seob. All rights reserved.
//

import UIKit

protocol DisplayDelegate: class {
    func display()
}

enum Operator: String {
    case addition = "+"
    case subtraction = "-"
    
    var calculate: (Int, Int) -> Int {
        switch self {
        case .addition:         return (+)
        case .subtraction:      return (-)
            
        }
    }
}

enum Command {
    case clear
    case equal
    case operation(Operator)
    case addNumber(Character)
}

class Display: UILabel{
    
    weak var delegate: DisplayDelegate?
 
    @objc func doSomething() {
        
        
        delegate?.display()
        
    }
    
}
