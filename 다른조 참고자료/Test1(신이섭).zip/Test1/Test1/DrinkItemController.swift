//
//  DrinkItemController.swift
//  Test1
//
//  Created by seob on 2018. 6. 9..
//  Copyright © 2018년 seob. All rights reserved.
//

import UIKit

protocol DrinkItemDelegate: class {
    func drink()
}

class DrinkItem: UIImageView {
    
    weak var drinkDelegate: DrinkItemDelegate?
    
    @objc func doSomething() {
        
        
        drinkDelegate?.drink()
        
    }
}
