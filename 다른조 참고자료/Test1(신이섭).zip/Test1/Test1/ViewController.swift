//
//  ViewController.swift
//  Test1
//
//  Created by seob on 2018. 6. 9..
//  Copyright © 2018년 seob. All rights reserved.
//

import UIKit

class ViewController: UIViewController, DisplayDelegate, InputDelegate, DrinkItemDelegate {
  
    //콜라, 사이다 이미지
    let colaImg = DrinkItem(frame: CGRect(x: 2, y: 10, width: 200, height: 200))
    let ciderImg = DrinkItem(frame: CGRect(x: 202, y: 10, width: 200, height: 200))
    //콜라, 사이다 가격표
    let colaLabel = Display(frame: CGRect(x: 2, y: 210, width: 200, height: 30))
    let ciderLabel = Display(frame: CGRect(x: 202, y: 210, width: 200, height: 30))
    //칸타타, 삼다수 이미지
    let kantataImg = DrinkItem(frame: CGRect(x: 2, y: 240, width: 200, height: 200))
    let samdaImg = DrinkItem(frame: CGRect(x: 202, y: 240, width: 200, height: 200))
    //칸타타, 삼다수 가격표
    let kantataLabel = Display(frame: CGRect(x: 2, y: 440, width: 200, height: 30))
    let samdaLabel = Display(frame: CGRect(x: 202, y: 440, width: 200, height: 30))
    //결과, 잔액
    let resultLabel = Display(frame: CGRect(x: 2, y: 470, width: 402, height: 50))
    let changeLabel = Display(frame: CGRect(x: 2, y: 520, width: 402, height: 50))
    //버튼부
    let chunWonButton = Input(frame: CGRect(x: 2, y: 570, width: 134, height: 20))
    let obekWonButton = Input(frame: CGRect(x: 136, y: 570, width: 134, height: 20))
    let returnButton = Input(frame: CGRect(x: 270, y: 570, width: 134, height: 20))
   

    var myPrice = 0 // 내가 충전한 금액
    
    override func viewDidLoad() {
        super.viewDidLoad()
        /**************************************************************
         굳이 딜리게이트를 사용하시려면 아래와 같이 그 해당 딜리게이트를 사용한다고 명시를 해줘야 사용가능합니다.
         근데 지금 딜리게이트는 음.... 아까 다른분이 말씀하신거처럼 아직 개념이 조금 다르게 아시는거같아서
         우선 작업하신 코드에서만 기능만 추가해놨으니 한번 보시면될거같아요.
         **************************************************************/
        chunWonButton.delegate = self
        obekWonButton.delegate = self
        returnButton.delegate = self
        
        kantataLabel.delegate = self
        changeLabel.delegate = self
        
        /**************************************************************
         UITapGestureRecognizer << 라벨을 클릭했을 시 버튼 addtarget 과 동일한 기능을 하는 역할
         isUserInteractionEnabled = bool
         **************************************************************/
 
        colaLabel.isUserInteractionEnabled = true
        ciderLabel.isUserInteractionEnabled = true
        kantataLabel.isUserInteractionEnabled = true
        samdaLabel.isUserInteractionEnabled = true
        
        colaLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(drink1(_:))))
        ciderLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(drink2(_:))))
        kantataLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(drink3(_:))))
        samdaLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(drink4(_:))))
        
        // MARK: 하단의 충전버튼 클릭시 이벤트
        chunWonButton.addTarget(self, action: #selector(input1(_:)), for: .touchUpInside)
        obekWonButton.addTarget(self, action: #selector(input2(_:)), for: .touchUpInside)
        returnButton.addTarget(self, action: #selector(input3(_:)), for: .touchUpInside)
        
  
        colaImg.image = UIImage(named: "cola")
        view.addSubview(colaImg)
        //
        colaLabel.text = "1000원"
       
        colaLabel.textAlignment = .center
        colaLabel.font = UIFont.boldSystemFont(ofSize: 25)
        view.addSubview(colaLabel)
        //
        ciderImg.image = UIImage(named: "cider")
        view.addSubview(ciderImg)
        //
        ciderLabel.text = "800원"
        ciderLabel.textAlignment = .center
        ciderLabel.font = UIFont.boldSystemFont(ofSize: 25)
        view.addSubview(ciderLabel)
        //
        kantataImg.image = UIImage(named: "kantata")
        view.addSubview(kantataImg)
        //
        kantataLabel.text = "1500원"
        kantataLabel.textAlignment = .center
        kantataLabel.font = UIFont.boldSystemFont(ofSize: 25)
        view.addSubview(kantataLabel)
        //
        samdaImg.image = UIImage(named: "samda")
        view.addSubview(samdaImg)
        //
        samdaLabel.text = "500원"
        samdaLabel.textAlignment = .center
        samdaLabel.font = UIFont.boldSystemFont(ofSize: 25)
        
        //
        resultLabel.text = "결과 : "
        resultLabel.textAlignment = .right
        resultLabel.font = UIFont.boldSystemFont(ofSize: 25)
        //
        changeLabel.text = "잔액 : "
        changeLabel.textAlignment = .right
        changeLabel.font = UIFont.boldSystemFont(ofSize: 25)
        //
        chunWonButton.setTitle("1000원", for: .normal)
        obekWonButton.setTitle("500원", for: .normal)
        returnButton.setTitle("반환", for: .normal)
 
        
 
        //
        view.addSubview(samdaLabel)
        view.addSubview(resultLabel)
        view.addSubview(changeLabel)
        //
        view.addSubview(chunWonButton)
        view.addSubview(obekWonButton)
        view.addSubview(returnButton)
        
        
    }
    
    // MARK: 각각 상품가격 클릭시 주문
    @objc func drink1(_ sender: Any) {
        calc(name: "콜라")
    }
    @objc func drink2(_ sender: Any) {
        calc(name: "사이다")
    }
    @objc func drink3(_ sender: Any) {
        calc(name: "커피")
    }
    @objc func drink4(_ sender: Any) {
        calc(name: "생수")
    }
    
    // MARK: 상품가격을 클릭했을경우 잔액 확인후 주문
    func calc(name: String){
        if productInfo(name: name) != nil {
            if let price = productInfo(name: name)?.price {
                if myPrice > price {
                    myPrice -= price
                    
                    resultLabel.text = "\(myPrice) 원이 남았습니다."
                    changeLabel.text = "\(myPrice) 원"
                    
                    alertWithTitle(title: "확인", message: "\(name) 주문 되었습니다.", ViewController: self)
                }else{
                    alertWithTitle(title: "Error", message: "잔액이 부족합니다.", ViewController: self)
                }
            }
        }else{
            alertWithTitle(title: "Error", message: "해당 상품이 존재하지 않습니다.", ViewController: self)
        }
    }
    
    /**************************************************************
     productInfo(name: String) -> (name: String, price: Int)?
     상품정보 (상품명 , 가격) 없을경우 nil 반환
     **************************************************************/
    func productInfo(name: String) -> (name: String, price: Int)? {
        let productInfoList: [(name: String, price: Int)] = [
            ("콜라", 1000),
            ("사이다", 800),
            ("커피", 1500),
            ("생수", 500),
            ]
        for productInfo in productInfoList {
            if productInfo.name == name {
                return productInfo
            }
        }
        return nil
    }
    
    // MARK: 충전금액 남은잔액
    func display(price: Int) {
        myPrice += price
        resultLabel.text = myPrice > 0 ? "\(myPrice) 원이 충전되었습니다." : ""
        changeLabel.text = "\(myPrice) 원"
    }
    
    // MARK: 하단의 충전금액 버튼 눌렀을경우
    
   //1000원 충전 버튼을 눌렀을경우
    @objc private func input1(_ sender: Any){
        display(price: 1000)
    }
    //500원 충전 버튼을 눌렀을경우
    @objc private func input2(_ sender: Any){
        display(price: 500)
    }
    
    //반환충전 버튼을 눌렀을경우
    @objc private func input3(_ sender: Any){
        let beforePrice = myPrice
        var message = ""
        message = beforePrice > 0 ? "총 \(beforePrice) 원 반환되었습니다." : ""
        resultLabel.text = message
        myPrice = 0
        changeLabel.text = "\(myPrice) 원"
    }
    
    /**************************************************************
     alert 함수정의
     alertWithTitle(title: String!, message: String, ViewController: UIViewController)
     사용방법 alertWithTitle(title : 제목 , message: 메세지 , ViewController: self)
     **************************************************************/
    func alertWithTitle(title: String!, message: String, ViewController: UIViewController) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default ,handler: nil);
        
        alert.addAction(action)
        ViewController.present(alert, animated: true, completion:nil)
    }
    
    func display(){
        
    }
    func drink(){
        
    }
    
     func input() {
        //잔액을 음료금액과 같게 입금하면 Input컨트롤러에서 반응
        resultLabel.text = "결과 : "
        //
        changeLabel.text = "잔액 : "
        
        
        if changeLabel.text == "\(String(describing: colaLabel.text))" && changeLabel.text == "\(String(describing: ciderLabel.text))" && changeLabel.text == "\(String(describing: kantataLabel.text))" && changeLabel.text == "\(String(describing: samdaLabel.text))"{
            present(self, animated: true)
        }else{
            let alert = UIAlertController(title: "금액 안맞음", message: "금액 안맞음", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (UIAlertAction) in
                return
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: { (UIAlertAction) in
                return
            }))


            present(alert, animated: true)
        }
    }
}
